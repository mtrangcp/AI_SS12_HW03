package com.abcbank.ekyc.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Thực thể biểu diễn thông tin tài khoản ngân hàng trong hệ thống eKYC.
 */
@Entity
@Table(name = "accounts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Account {

    /**
     * Khóa chính tự sinh của tài khoản.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Họ và tên đầy đủ của chủ tài khoản.
     */
    @Column(name = "full_name", nullable = false)
    private String fullName;

    /**
     * Số điện thoại đăng ký tài khoản.
     */
    @Column(name = "phone", nullable = false, length = 15)
    private String phone;

    /**
     * Địa chỉ Email liên hệ.
     */
    @Column(name = "email", nullable = false)
    private String email;

    /**
     * Số Căn cước công dân (CCCD) gồm 12 chữ số.
     */
    @Column(name = "citizen_id", nullable = false, unique = true, length = 12)
    private String citizenId;

    /**
     * Số tài khoản ngân hàng được sinh tự động sau khi đăng ký.
     */
    @Column(name = "account_number", nullable = false, unique = true, length = 20)
    private String accountNumber;

    /**
     * Trạng thái hoạt động của tài khoản (PENDING/ACTIVE).
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private AccountStatus status;
}
