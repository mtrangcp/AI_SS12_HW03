package com.abcbank.ekyc.repository;

import com.abcbank.ekyc.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository cung cấp các phương thức truy vấn cơ sở dữ liệu đối với thực thể Account.
 */
@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    /**
     * Tìm kiếm tài khoản theo số tài khoản ngân hàng.
     *
     * @param accountNumber Số tài khoản cần tìm.
     * @return Một Optional chứa thông tin tài khoản nếu tìm thấy.
     */
    Optional<Account> findByAccountNumber(String accountNumber);

    /**
     * Kiểm tra xem số CCCD đã tồn tại trong hệ thống chưa.
     *
     * @param citizenId Số CCCD cần kiểm tra.
     * @return true nếu số CCCD đã tồn tại, ngược lại trả về false.
     */
    boolean existsByCitizenId(String citizenId);

    /**
     * Kiểm tra xem địa chỉ Email đã tồn tại trong hệ thống chưa.
     *
     * @param email Địa chỉ email cần kiểm tra.
     * @return true nếu email đã tồn tại, ngược lại trả về false.
     */
    boolean existsByEmail(String email);

    /**
     * Kiểm tra xem số tài khoản ngân hàng đã tồn tại trong hệ thống chưa.
     *
     * @param accountNumber Số tài khoản cần kiểm tra.
     * @return true nếu số tài khoản đã tồn tại, ngược lại trả về false.
     */
    boolean existsByAccountNumber(String accountNumber);
}
