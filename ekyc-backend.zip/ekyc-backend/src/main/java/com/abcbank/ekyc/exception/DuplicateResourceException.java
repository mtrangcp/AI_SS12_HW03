package com.abcbank.ekyc.exception;

/**
 * Ngoại lệ tùy chỉnh ném ra khi tài nguyên yêu cầu tạo mới đã tồn tại trong hệ thống (ví dụ: trùng Số CCCD hoặc Email).
 */
public class DuplicateResourceException extends RuntimeException {

    /**
     * Khởi tạo một ngoại lệ DuplicateResourceException mới với thông điệp lỗi cụ thể.
     *
     * @param message Thông điệp mô tả lỗi chi tiết.
     */
    public DuplicateResourceException(String message) {
        super(message);
    }
}
