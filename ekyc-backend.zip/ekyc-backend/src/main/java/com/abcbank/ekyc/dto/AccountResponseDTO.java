package com.abcbank.ekyc.dto;

import com.abcbank.ekyc.entity.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Đối tượng DTO phản hồi thông tin sau khi đăng ký tài khoản eKYC thành công.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountResponseDTO {

    /**
     * ID hệ thống của tài khoản vừa tạo.
     */
    private Long accountId;

    /**
     * Số tài khoản ngân hàng được cấp.
     */
    private String accountNumber;

    /**
     * Trạng thái hiện tại của tài khoản (PENDING/ACTIVE).
     */
    private AccountStatus status;
}
