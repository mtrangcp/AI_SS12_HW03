package com.abcbank.ekyc.entity;

/**
 * Trạng thái của tài khoản eKYC trong hệ thống.
 */
public enum AccountStatus {
    /**
     * Tài khoản đang chờ phê duyệt/xác thực.
     */
    PENDING,

    /**
     * Tài khoản đã hoạt động.
     */
    ACTIVE
}
