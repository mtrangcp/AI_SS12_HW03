package com.abcbank.ekyc.exception;

import lombok.Builder;
import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Bộ xử lý ngoại lệ tập trung cho toàn bộ ứng dụng eKYC.
 * Lớp này sẽ đánh chặn các ngoại lệ ném ra từ Controller và định dạng lại phản hồi lỗi JSON đẹp mắt cho Client.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Xử lý ngoại lệ trùng lặp tài nguyên (DuplicateResourceException).
     * Trả về HTTP Status 400 Bad Request kèm thông báo lỗi cụ thể.
     *
     * @param ex      Ngoại lệ bắt được.
     * @param request Yêu cầu web hiện tại.
     * @return Đối tượng ResponseEntity chứa thông tin lỗi định dạng chuẩn.
     */
    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateResourceException(DuplicateResourceException ex, WebRequest request) {
        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.BAD_REQUEST.value())
                .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                .message(ex.getMessage())
                .path(request.getDescription(false).replace("uri=", ""))
                .build();

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    /**
     * Xử lý ngoại lệ validation dữ liệu đầu vào (MethodArgumentNotValidException).
     * Trả về HTTP Status 400 Bad Request kèm theo danh sách các trường bị lỗi và thông điệp chi tiết.
     *
     * @param ex      Ngoại lệ validation bắt được.
     * @param request Yêu cầu web hiện tại.
     * @return Đối tượng ResponseEntity chứa thông tin lỗi validation định dạng chuẩn.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException ex, WebRequest request) {
        Map<String, String> validationErrors = new HashMap<>();
        for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
            validationErrors.put(fieldError.getField(), fieldError.getDefaultMessage());
        }

        // Tạo thông điệp lỗi tổng quát từ các lỗi validation
        String message = "Dữ liệu đầu vào không hợp lệ. Vui lòng kiểm tra lại.";
        if (!validationErrors.isEmpty()) {
            message = String.join(", ", validationErrors.values());
        }

        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.BAD_REQUEST.value())
                .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                .message(message)
                .path(request.getDescription(false).replace("uri=", ""))
                .build();

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    /**
     * Xử lý tất cả các ngoại lệ chung khác của hệ thống.
     *
     * @param ex      Ngoại lệ bắt được.
     * @param request Yêu cầu web hiện tại.
     * @return Đối tượng ResponseEntity chứa thông tin lỗi hệ thống.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneralException(Exception ex, WebRequest request) {
        ErrorResponse errorResponse = ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase())
                .message("Đã xảy ra lỗi hệ thống. Vui lòng liên hệ quản trị viên.")
                .path(request.getDescription(false).replace("uri=", ""))
                .build();

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Lớp DTO nội bộ biểu diễn cấu trúc thông điệp phản hồi lỗi chuẩn của ngân hàng.
     */
    @Data
    @Builder
    public static class ErrorResponse {
        private LocalDateTime timestamp;
        private int status;
        private String error;
        private String message;
        private String path;
    }
}
