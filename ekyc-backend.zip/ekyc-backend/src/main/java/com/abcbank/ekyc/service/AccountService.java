package com.abcbank.ekyc.service;

import com.abcbank.ekyc.dto.AccountRequestDTO;
import com.abcbank.ekyc.dto.AccountResponseDTO;

/**
 * Interface cung cấp các nghiệp vụ quản lý tài khoản ngân hàng eKYC.
 */
public interface AccountService {

    /**
     * Thực hiện đăng ký mở tài khoản ngân hàng mới qua luồng eKYC.
     *
     * @param request Thông tin yêu cầu đăng ký mở tài khoản.
     * @return Thông tin tài khoản sau khi đăng ký thành công.
     */
    AccountResponseDTO register(AccountRequestDTO request);
}
