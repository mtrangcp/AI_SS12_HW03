package com.abcbank.ekyc.controller;

import com.abcbank.ekyc.dto.AccountRequestDTO;
import com.abcbank.ekyc.dto.AccountResponseDTO;
import com.abcbank.ekyc.service.AccountService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller cung cấp API quản lý thông tin tài khoản ngân hàng.
 */
@RestController
@RequestMapping("/api/v1/accounts")
@RequiredArgsConstructor
@Slf4j
public class AccountController {

    private final AccountService accountService;

    /**
     * API thực hiện đăng ký mở tài khoản ngân hàng mới qua luồng eKYC.
     * Kích hoạt validation dữ liệu đầu vào bằng cách sử dụng annotation @Valid.
     *
     * @param request DTO chứa thông tin đăng ký của khách hàng.
     * @return ResponseEntity chứa DTO kết quả tài khoản đã đăng ký thành công và mã trạng thái HTTP 201 (Created).
     */
    @PostMapping("/register")
    public ResponseEntity<AccountResponseDTO> registerAccount(@Valid @RequestBody AccountRequestDTO request) {
        log.info("Nhận yêu cầu đăng ký mở tài khoản cho khách hàng qua API: {}", request.getFullName());
        
        // Gọi service xử lý logic nghiệp vụ đăng ký mở tài khoản
        AccountResponseDTO response = accountService.register(request);
        
        // Trả về mã trạng thái HTTP 201 Created cùng với kết quả đăng ký
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}
