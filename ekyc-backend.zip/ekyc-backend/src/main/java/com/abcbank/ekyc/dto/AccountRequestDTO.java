package com.abcbank.ekyc.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Đối tượng DTO nhận thông tin yêu cầu đăng ký mở tài khoản eKYC mới.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountRequestDTO {

    /**
     * Họ và tên đầy đủ của khách hàng. Không được để trống.
     */
    @NotBlank(message = "Họ và tên không được để trống")
    private String fullName;

    /**
     * Số điện thoại liên hệ. Không được để trống và phải đúng định dạng số điện thoại (ví dụ: từ 9 đến 11 số).
     */
    @NotBlank(message = "Số điện thoại không được để trống")
    @Pattern(regexp = "^\\+?[0-9]{9,15}$", message = "Số điện thoại không hợp lệ")
    private String phone;

    /**
     * Địa chỉ Email. Không được để trống và phải tuân thủ định dạng email chuẩn.
     */
    @NotBlank(message = "Email không được để trống")
    @Email(message = "Email không đúng định dạng")
    private String email;

    /**
     * Số Căn cước công dân (CCCD). Không được để trống và phải bao gồm chính xác 12 chữ số.
     */
    @NotBlank(message = "Số CCCD không được để trống")
    @Pattern(regexp = "^\\d{12}$", message = "Số CCCD phải đúng 12 chữ số")
    private String citizenId;
}
